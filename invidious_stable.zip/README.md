**Screenshot:**

![Screenshot](/Screenshots/1.png)


**Features:**

* Stream Videos from Invidious
* Get Video Recommendations Based On Watch History
* Browse Trending Videos


**How to Install (Official Plugin Repository):**

1) Navigate to Movian/M7 > Settings > General > Alternative Plugin Repository URL:

2) Set this value to 'https://bit.ly/streamprom7'

3) Return to Movian/M7 Home Screen.

4) Navigate to Plugins > Browse Available Plugins > Video Streaming > Invidious

5) Select Install (Plugin will now update automatically).

6) Return to Movian/M7 Home Screen and Enjoy!


![Stable-Release plugin.zip Download (Latest Version)](/invidious_stable.zip?raw=true)


**Available Languages:**

* English


